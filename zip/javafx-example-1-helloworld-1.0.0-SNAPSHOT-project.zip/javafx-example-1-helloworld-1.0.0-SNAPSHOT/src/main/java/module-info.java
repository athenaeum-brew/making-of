module com.cthiebaud.javafx {
    requires javafx.controls;
    requires transitive javafx.graphics;

    exports com.cthiebaud.javafx;
}
