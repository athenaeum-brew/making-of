module com.cthiebaud.javafx {
    requires javafx.controls;
    requires transitive javafx.web;

    exports com.cthiebaud.javafx;
}
